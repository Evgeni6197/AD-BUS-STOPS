
document.addEventListener("DOMContentLoaded", ()=>{

    // const  dashboard_general_container = document.getElementById('dashboard_general_container');
    // const message = dashboard_general_container.dataset.message;
    // const upload_form = document.getElementById('upload_form');
    // const upload_button = document.getElementById('upload_button');
    // const animation_container = document.getElementById('animation_container');

    // if (message === 'invalid_file'){
    //     alert ('Invalid or Duplicate File or Date')
    // }

    // upload_form.addEventListener('submit',()=>{
    //     upload_button.disabled = true;
    //     animation_container.classList.remove('invisible');  
    // })

}) 