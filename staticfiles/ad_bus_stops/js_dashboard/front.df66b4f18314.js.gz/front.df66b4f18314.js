
document.addEventListener("DOMContentLoaded", ()=>{

    const  dashboard_general_container = document.getElementById('dashboard_general_container');
    const message = dashboard_general_container.dataset.message;

    if (message === 'app_explorer_required'){
        alert( `ACCESS DENIED.

During the commercial promotion stage of the app: 

In  order to access any dashboard action, an Explorer 
account is required. Simply tap on the logo.`)
    } else if (message === 'uploaded'){
        alert ('File successfully uploaded. BaseDate has been updated.')
    }   
})






 