
let count = 0;

document.getElementById('button').addEventListener('click',()=>{

    count++;
    document.getElementById('test').innerHTML = count;

});








